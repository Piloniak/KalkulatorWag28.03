import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
const scaleNames = {
  kg: 'kg',
  lbs: 'lbs',
  t: 'tons'
};

function toKg(lbs) {
  return lbs / 2.204;
}

function toLbs(kg) {
  return  kg * 2.204;
}
function tryConvert(Weight, convert) {
  const input = parseFloat(Weight);
  if (Number.isNaN(input)) {
    return '';
  }
  const output = convert(input);
  const rounded = Math.round(output * 1000) / 1000;
  return rounded.toString();
}

class WeightInput extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    this.props.onWeightChange(e.target.value);
  }

  render() {
    const Weight= this.props.Weight;
    const scale = this.props.scale;
    return (
      <div>
        {scaleNames[scale]}:
        <input value={Weight}
               onChange={this.handleChange} />
      </div>
    );
  }
}

class Calculator extends React.Component {
  constructor(props) {
    super(props);
    this.handlekgChange = this.handlekgChange.bind(this);
    this.handleLbsChange = this.handleLbsChange.bind(this);
    this.handleTonsChange = this.handleTonsChange.bind(this);

    this.state = {Weight: '', scale: ''};
  }

  handlekgChange(Weight) {
    this.setState({scale: 'kg', Weight});
  }

  handleLbsChange(Weight) {
    this.setState({scale: 'lbs', Weight});
  }
  
  handleTonsChange(Weight) {
    this.setState({scale: 't', Weight});
  }

  render() {
    const scale = this.state.scale;
    const Weight= this.state.Weight;
    const kg = scale === 'lbs' ? tryConvert(Weight, toKg) : Weight;
    const Lbs = scale === 'kg' ? tryConvert(Weight, toLbs) : Weight;
    // const tons = scale === 't' ? tryConvert(Weight, toTons): Weight;
    const converted = Lbs / 2.204 /1000;
    const rounded = Math.round(converted * 1000) / 1000;
    const tons = rounded.toString();
    

    return (
      <div>
        <WeightInput
          scale="kg"
          Weight={kg}
          onWeightChange={this.handlekgChange} />
        <WeightInput
          scale="lbs"
          Weight={Lbs}
          onWeightChange={this.handleLbsChange} />
          <WeightInput
          scale="t"
          Weight={tons}
          
          />
          
          <p>dekagramy: {kg*10}<br/>
            centygramy: {kg*10000}<br/>
            nanogramy: {kg*1000000000}<br/>
            miligramy: {kg*1000000}<br/>
            gramy: {kg*1000}<br/>
            kwintyle: {kg*0.01}<br/>
            megatony: {tons*0.001}<br/></p>
            
      </div>
    );
  }
}
const tempscaleNames = {
  c: 'Celsius',
  f: 'Fahrenheit'
};

function toCelsius(fahrenheit) {
  return (fahrenheit - 32) * 5 / 9;
}

function toFahrenheit(celsius) {
  return (celsius * 9 / 5) + 32;
}

function temptryConvert(temperature, convert) {
  const input = parseFloat(temperature);
  if (Number.isNaN(input)) {
    return '';
  }
  const output = convert(input);
  const rounded = Math.round(output * 1000) / 1000;
  return rounded.toString();
}

class TemperatureInput extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    this.props.onTemperatureChange(e.target.value);
  }

  render() {
    const temperature = this.props.temperature;
    const scale = this.props.scale;
    return (
      <div>
        {tempscaleNames[scale]}:
        <input value={temperature}
               onChange={this.handleChange} />
      </div>
    );
  }
}

class TempCalculator extends React.Component {
  constructor(props) {
    super(props);
    this.handleCelsiusChange = this.handleCelsiusChange.bind(this);
    this.handleFahrenheitChange = this.handleFahrenheitChange.bind(this);
    this.state = {temperature: '', scale: 'c'};
  }

  handleCelsiusChange(temperature) {
    this.setState({scale: 'c', temperature});
  }

  handleFahrenheitChange(temperature) {
    this.setState({scale: 'f', temperature});
  }

  render() {
    const scale = this.state.scale;
    const temperature = this.state.temperature;
    const celsius = scale === 'f' ? temptryConvert(temperature, toCelsius) : temperature;
    const fahrenheit = scale === 'c' ? temptryConvert(temperature, toFahrenheit) : temperature;

    return (
      <div>
        <TemperatureInput
          scale="c"
          temperature={celsius}
          onTemperatureChange={this.handleCelsiusChange} />
        <TemperatureInput
          scale="f"
          temperature={fahrenheit}
          onTemperatureChange={this.handleFahrenheitChange} />
        
      </div>
    );
  }
}

ReactDOM.render(
  <div>
    <TempCalculator/>
    <br/>
  <Calculator />
  </div>,
  document.getElementById('root')
);
reportWebVitals();
